package com.moac.android.myrssreader.ui.feed;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.moac.android.myrssreader.MyRssReaderApplication;
import com.moac.android.myrssreader.R;
import com.moac.android.myrssreader.api.BbcRssApi;
import com.moac.android.myrssreader.model.FeedItem;
import com.moac.android.myrssreader.model.RssFeedResponse;
import com.moac.android.myrssreader.ui.article.ArticleActivity;

import java.util.List;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * This is our main Activity, it will show a list item RSS feed items retrieved from the internet.
 */
public class RssFeedActivity extends AppCompatActivity {

    private static final String TAG = RssFeedActivity.class.getSimpleName();

    // TODO A reference to the RecyclerView
    // TODO A single onClickListener which launches the ArticleActivity
    private RecyclerView feedRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the Activity UI.
        setContentView(R.layout.activity_rss_feed);
        initFeedView();
        loadFeed();
        // TODO Invoke the initFeedView()
        // TODO Invoke the loadFeed()
    }

    private void initFeedView() {
        // TODO Get a reference to the RecyclerView widget and set the LayoutManager
        feedRecyclerView = (RecyclerView)findViewById(R.id.recyclerView_feed);
        feedRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    /**
     * Loads an RSS Feed into the UI.
     */
    // TODO Trigger the loading of the feed.
    private void loadFeed() {
        // TODO Use Retrofit to fetch the feed items - this is asynchronous, so supply a set of callbacks, one for success and one for error.

        getBbcRssApi().getFeedItems(new Callback<RssFeedResponse>() {
            @Override
            public void success(RssFeedResponse rssFeedResponse, Response response) {
                List<FeedItem> feedItemList = rssFeedResponse.getChannel().getFeedItems();
                Log.d(TAG, "Got RssFeedResponse size: " + rssFeedResponse.getChannel().getFeedItems().size());

                FeedItemListAdapter adapter = new FeedItemListAdapter(feedItemList,
                        new FeedItemListAdapter.OnFeedItemClickedListener() {
                            @Override
                            public void onFeedItemClicked(FeedItem item) {
                                ArticleActivity.launch(RssFeedActivity.this, item.getLink());
                            }
                        });
                feedRecyclerView.setAdapter(adapter);
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d(TAG, "Got Error from BBC Feed API: ", error);
            }

        });
        // TODO Report success to the UI using a Snackbar.
        // TODO Report failure to the UI using a Snackbar and log it.
        // TODO Report the failure to application logs
    }

    private BbcRssApi getBbcRssApi() {
        return ((MyRssReaderApplication)getApplication()).getBbcRssApi();
    }

}
