package com.moac.android.myrssreader;

import android.app.Application;
import android.util.Log;

import com.moac.android.myrssreader.api.BbcRssApi;

import retrofit.ErrorHandler;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.converter.SimpleXMLConverter;

/**
 * Created by young on 9/19/15.
 */
public class MyRssReaderApplication extends Application {

    private static final String TAG = MyRssReaderApplication.class.getSimpleName();

    private BbcRssApi bbcRssApi;

    @Override
    public void onCreate() {
        super.onCreate();
        initBbcRssApi();
    }

    public BbcRssApi getBbcRssApi() {
        return bbcRssApi;
    }

    private void initBbcRssApi() {
        bbcRssApi = new RestAdapter.Builder()
                .setConverter(new SimpleXMLConverter())
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .setErrorHandler(new ErrorHandler() {
                    @Override
                    public Throwable handleError(RetrofitError cause) {
                        Log.e(TAG, "We got an error!!!", cause);
                        return cause;
                    }
                })
                .setEndpoint("http://feeds.bbci.co.uk/")
                .build()
                .create(BbcRssApi.class);
    }

}
