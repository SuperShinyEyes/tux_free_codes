package com.moac.android.myrssreader.ui.article;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

import com.moac.android.myrssreader.R;

public class ArticleActivity extends AppCompatActivity {


    private static final String URL_KEY = "URL";

    // TODO Write a static launcher method that passes the URL String to the ArticleActivity
    public static void launch(Context context, String url) {
        Intent intent = new Intent(context, ArticleActivity.class);
        intent.putExtra(URL_KEY, url);
        context.startActivity(intent);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article);

        WebView articleWebView = (WebView)findViewById(R.id.webView_article);

        // TODO Retrieve the Article URL from the Intent parameters
        String url = getIntent().getStringExtra(URL_KEY);

        // TODO Load the URL into the WebView
        articleWebView.loadUrl(url);
    }
}
