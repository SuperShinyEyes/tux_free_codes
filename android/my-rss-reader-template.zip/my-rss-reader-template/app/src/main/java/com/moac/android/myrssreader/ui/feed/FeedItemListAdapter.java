package com.moac.android.myrssreader.ui.feed;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.moac.android.myrssreader.R;
import com.moac.android.myrssreader.model.FeedItem;

import java.util.List;

/**
 * Creates View items to be displayed in a RecyclerView, populated with data.
 */
public class FeedItemListAdapter extends RecyclerView.Adapter<FeedItemListAdapter.ViewHolder> {

    // TODO Create a constructor that uses a List<Item> and an OnFeedItemClickListener
    public interface OnFeedItemClickedListener {
        void onFeedItemClicked(FeedItem item);
    }

    private final List<FeedItem> feedItems;
    private final OnFeedItemClickedListener onFeedItemClickedListener;

    public FeedItemListAdapter(List<FeedItem> feedItems,
                               OnFeedItemClickedListener onFeedItemClickedListener) {
        this.feedItems = feedItems;
        this.onFeedItemClickedListener = onFeedItemClickedListener;
    }



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent,
                                         int viewType) {
        // Create a new View instances from the XML layout definition
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.view_feed_item, parent, false);
        return new ViewHolder(view);
        // TODO Inflate view_feed_item and return a new ViewHolder using the View
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // TODO Get the data items and bind it to the ViewHolder (set the value!)
        holder.bind(feedItems.get(position), onFeedItemClickedListener);
    }

    // Returns the size of the dataset
    @Override
    public int getItemCount() {
        // TODO Make this return
        return feedItems.size();
    }


    /**
     * A recyclable representation of a View entity
     */
    static class ViewHolder extends RecyclerView.ViewHolder {

        View rootView;
        TextView titleTextView;
        TextView descriptionTextView;

        ViewHolder(View view) {
            super(view);
            rootView = view;
            // TODO Get references to the root, title and description Views
            titleTextView = (TextView)view.findViewById(R.id.textView_title);
            descriptionTextView = (TextView)view.findViewById(R.id.textView_description);
        }

        void bind(final FeedItem feedItem, final OnFeedItemClickedListener onFeedItemClickedListener) {
            rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onFeedItemClickedListener.onFeedItemClicked(feedItem);
                }
            });
            titleTextView.setText(feedItem.getTitle());
            descriptionTextView.setText(feedItem.getDescription());
        }

        // TODO Add a bind() method assign the values to the fields (and the click listener!)

    }
}
